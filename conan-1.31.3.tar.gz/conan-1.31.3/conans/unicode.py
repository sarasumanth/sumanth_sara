import os

# FIXME: This has to be removed in Conan 2.0
get_cwd = os.getcwd
